package test;

import java.io.IOException;
import java.net.URISyntaxException;

public class Main {
    public static void main(String[] args) throws IOException, URISyntaxException {
        Printer printer = new Printer();
        try {
            System.out.println(printer.test());
        } catch (Exception e) {
            throw e;
        }

    }

}
