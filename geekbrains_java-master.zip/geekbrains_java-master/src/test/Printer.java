package test;

import java.io.IOException;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;

public class Printer {

    public String test() throws URISyntaxException, IOException {
        InputStream a = getClass().getResourceAsStream("/application.conf");
        byte[] bytes = new byte[a.available()];
        a.read(bytes);
        return new String(bytes, StandardCharsets.UTF_8);
    }

}
