package geekbrains.lesson_4.guess_the_number;

import java.util.Scanner;

public class MainGameUp {
  private static Scanner scanner = new Scanner(System.in);

  public static void main(String[] args) {
    System.out.println("Ваша задача угадать число.");
    int range = 30; //объявляем переменную: тип, название, присваиваем значение (в ней зранится число 10)
    int number = (int) (Math.random() * range); //генерит рандомное число

    playLevel(range, number); //вызываем метод и передаем параметры

    scanner.close(); // сканер при создании выделяет ресурсы, освобождаем
  }

  private  static void  playLevel (int range, int number) {
    while (true) {
      System.out.println("Угадайте число от 0 до " + range);
      int input_number =  scanner.nextInt();
      if(input_number == number) {
        System.out.println("Вы угадали!");
        break; //прерываем цикл
      } else if(input_number > number) {
        System.out.println("Загаданное число меньше");
      } else {
        System.out.println("Загаданное число больше");
      }
    }
  }
}
