package geekbrains.lesson_3.guess_the_number;

import java.util.Scanner;

public class MainGame {
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    System.out.println("Ваша задача угадать число.");
    int range = 30; //объявляем переменную: тип, название, присваиваем значение (в ней зранится число 10)
    int number = (int) (Math.random() * range); //генерит рандомное число
    while (true) {
      System.out.println("Угадайте число от 0 до " + range);
      int input_number = scanner.nextInt();
      if(input_number == number) {
          System.out.println("Вы угадали!");
          break; //прерываем цикл
      } else if(input_number > number) {
          System.out.println("Загаданное число меньше");
      } else {
          System.out.println("Загаданное число больше");
      }
    }
    scanner.close(); // сканер при создании выделяет ресурсы, освобождаем
  }
}
