package geekbrains.lesson_1.hello_world;

public class Main {

    public static void main(String[] args) {
        System.out.println("Я буду изучать Java!");
    }
}
