package geekbrains.lesson_5.guess_the_number;

import java.util.Scanner;

//3 уровня, 1 1-10, 2 1-20, 3 1-30
public class MainGameLevels {

  private static Scanner scanner = new Scanner(System.in);

  public static void main(String[] args) {
    System.out.println("Ваша задача угадать число.");
    for(int i =10; i <= 30; i += 10){
      // так как рейндж меняется в цикле фор - удаляем переменную рейндж и заменяем ее на i
      int number = (int) (Math.random() * i); //генерит рандомное число
      playLevel(i, number); //вызываем метод и передаем параметры
    }

    scanner.close(); // сканер при создании выделяет ресурсы, освобождаем
  }

  private  static void  playLevel (int range, int number) {
    while (true) {
      System.out.println("Угадайте число от 0 до " + range);
      int input_number =  scanner.nextInt();
      if(input_number == number) {
        System.out.println("Вы угадали!");
        break; //прерываем цикл
      } else if(input_number > number) {
        System.out.println("Загаданное число меньше");
      } else {
        System.out.println("Загаданное число больше");
      }
    }
  }
}
